#ifndef MYLIB_H
#define MYLIB_H

int parse_cli(int argc, char *argv[]);

#endif // MYLIB_H