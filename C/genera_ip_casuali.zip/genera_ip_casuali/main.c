#include <stdio.h>
#include <stdlib.h>
#include "MyLib.h"

 int main(int argc, char *argv[]) {
    // Call the function to parse command line arguments
    parse_cli(argc, argv);
    
    // Additional code can be added here as needed
    return 0;